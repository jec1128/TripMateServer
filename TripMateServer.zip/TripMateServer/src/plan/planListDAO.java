package plan;

import java.sql.*;
import java.util.*;

public class planListDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public planListDAO() throws ClassNotFoundException, SQLException {
		try {
			String URL = "jdbc:mysql://localhost:3306/triptest?serverTimezone=Asia/Seoul&autoReconnect=true&useSSL=false&allowPublicKeyRetrieval=true";
			String id = "root";
			String password = "heart44";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(URL, id, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getIndex() {

		String SQL = "SELECT COUNT(*) FROM tripplan";

		try {
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt(1) + 1;
			} else {
				return 1;// ù ��° �÷��� ���
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		//System.out.println("\nERROR: �ڵ� ���� ����\n");
		return 0;
	}
	
	public String createCode() {

		int serial = getIndex();

		String suffix = String.format("%03d", serial);
		String planListCode = "PLANLIST-" + suffix;

		//System.out.println(planListCode + "�ڵ� ������");

		return planListCode;
	}
	
	public String AddList(planList planlist) {
		try {
			String SQL = "INSERT INTO tripplan(plan_code, plan_place, plan_title, trip_start_date, trip_end_date, delete_state) VALUES (?, ?, ?, ?, ?, ?)";
			
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, createCode());
			pstmt.setString(2, planlist.getPlanPlace());
			pstmt.setString(3, planlist.getPlanTitle());
			pstmt.setString(4, planlist.getStartDate());
			pstmt.setString(5, planlist.getEndDate());
			pstmt.setInt(6, 0);
			int result = pstmt.executeUpdate();
			if (result >= 0)
				return "success";
			/*
			String SQL2 = "select plan_code, plan_place, plan_title, trip_start_date, trip_end_date from tripplan";

			pstmt = conn.prepareStatement(SQL2);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String code = rs.getString("plan_code");
				String place = rs.getString("plan_place");
				String title = rs.getString("plan_title");
				String start = rs.getString("trip_start_date");
				String end = rs.getString("trip_end_date");
			}*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "db-error";
	}
	
	public String ListView(planList planlist) {
		String SQL2 = "select plan_code, plan_place, plan_title, trip_start_date, trip_end_date from tripplan";
		try {
			pstmt = conn.prepareStatement(SQL2);
			rs = pstmt.executeQuery();
			String code = createCode();
			while(rs.next()) {
				if(code.equals(rs.getString("plan_code"))){
					code = rs.getString("plan_code");
					String place = rs.getString("plan_place");
					String title = rs.getString("plan_title");
					String start = rs.getString("date_format(trip_start_date, '%y/%m/%d')");
					String end = rs.getString("date_format(trip_end_date, '%y/%m/%d')");
				}
				
			}
		}catch (Exception e) {
	         e.printStackTrace();
		}
		return "db-error";
	}
	
}
